<?
class bd{
	// Aributos
	var $a_mensError;
	var $a_bandError;
	var $a_numRegistros;
	var $a_conexion;
	var $a_resuConsulta;
	var $a_nombBD;

	/*
	 * Constructor de la clase
	 * $p_servidor -> nombre del servidor
	 * $p_usuario -> nombre e usuario
	 * $p_cpassword -> contraseña de usuario
	 * $p_nomBD -> nombre de la base de datos
	 */
	function bd($p_servidor, $p_usuario, $p_cpassword, $p_nomBD){
		$this->m_abrir($p_servidor, $p_usuario, $p_cpassword);
		$this->a_nomBD = $p_nomBD;
	}

	// Abrir conexion
	function m_abrir($p_servidor, $p_usuario, $p_cpassword){
		$this->a_conexion = mysql_connect($p_servidor, $p_usuario, $p_cpassword);
		if(mysql_error() > "")
			$this->a_bandError=true;
		else
			$this->a_bandError=false;
	}

	// Seleccionar la base de datos
	function m_seleBD(){
		mysql_select_db($this->a_nomBD, $this->a_conexion);
	}

	// Realiza consulta en BD
	function m_consulta($p_query){
		$this->m_seleBD();
		//echo "<br><br>funcion m_consulta: ". $p_query ."<br><br>";
		$this->a_resuConsulta = mysql_query($p_query);
		//echo "<br><br>resuConsulta: ". $this->a_resuConsulta ."<br><br>";
		$this->a_mensError=mysql_error();	// si no hay error, se asigna cadena vacía a a_error
		if($this->a_mensError > ""){
			$this->a_mensError .= " -> " .$p_query;
			$this->a_bandError = true;
		}else{
			$this->a_bandError = false;
			$this->a_numRegistros = mysql_num_rows($this->a_resuConsulta);
		}
	}

} // Termina clase

?>
